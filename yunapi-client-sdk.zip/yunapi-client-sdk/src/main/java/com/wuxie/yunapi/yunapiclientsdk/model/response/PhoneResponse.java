package com.wuxie.yunapi.yunapiclientsdk.model.response;

import lombok.NoArgsConstructor;
import yunapiCommon.common.BaseResponse;

/**
 * @author wuxie
 * @date 2023/10/10 11:40
 * @description 该文件的描述 todo
 */

public class PhoneResponse  extends ResultResponse {
    private static final long serialVersionUID = 1655054012936648591L;
    private String text;
}
